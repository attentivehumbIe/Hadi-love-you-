document.getElementById("magic-button").addEventListener("click", () => {
  const container = document.getElementById("hearts-container");
  
  for (let i = 0; i < 100; i++) {
    const heart = document.createElement("div");
    heart.classList.add("heart");
    heart.style.left = `${Math.random() * 100}%`;
    heart.style.animationDelay = `${Math.random() * 3}s`;
    heart.style.backgroundColor = `hsl(${Math.random() * 360}, 70%, 70%)`;
    container.appendChild(heart);

    setTimeout(() => heart.remove(), 3000); // Удаляем сердечки через 3 секунды
  }
});
